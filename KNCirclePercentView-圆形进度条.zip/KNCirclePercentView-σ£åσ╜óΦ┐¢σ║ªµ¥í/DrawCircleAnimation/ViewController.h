//
//  ViewController.h
//  DrawCircleAnimation
//
//  Created by Khoi Nguyen Nguyen on 11/23/15.
//  Copyright © 2015 Khoi Nguyen Nguyen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

