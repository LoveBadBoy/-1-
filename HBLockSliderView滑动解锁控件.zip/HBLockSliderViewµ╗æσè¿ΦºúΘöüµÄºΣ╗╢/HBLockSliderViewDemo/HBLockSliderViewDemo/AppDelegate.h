//
//  AppDelegate.h
//  HBLockSliderViewDemo
//
//  Created by 屌炸天 on 16/9/21.
//  Copyright © 2016年 yhb. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

