//
//  ViewController.m
//  HBLockSliderViewDemo
//
//  Created by 屌炸天 on 16/9/21.
//  Copyright © 2016年 yhb. All rights reserved.
//

#import "ViewController.h"
#import "HBLockSliderView.h"
#define kScreenW [UIScreen mainScreen].bounds.size.width
@interface ViewController ()<HBLockSliderDelegate>
@property (nonatomic,strong) HBLockSliderView *slider1;
@property (nonatomic,strong) HBLockSliderView *slider2;
@property (nonatomic,strong) HBLockSliderView *slider3;
@end
@implementation ViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];

    _slider2 = [[HBLockSliderView alloc] initWithFrame:CGRectMake(20, 150, kScreenW - 20 * 2, 40)];
    _slider2.layer.borderColor = [UIColor colorWithRed:153.0/255.0 green:153.0/255.0 blue:153.0/255.0 alpha:0.4].CGColor;
    _slider2.layer.borderWidth = 1;
    [_slider2 setColorForBackgroud:[UIColor colorWithRed:227.0/255.0 green:229.0/255.0 blue:236.0/255.0 alpha:1] foreground:[UIColor colorWithRed:227.0/255.0 green:229.0/255.0 blue:236.0/255.0 alpha:1] thumb:[UIColor colorWithRed:227.0/255.0 green:229.0/255.0 blue:236.0/255.0 alpha:1] border:[UIColor blackColor] textColor:[UIColor colorWithRed:147.0/255.0 green:147.0/255.0 blue:147.0/255.0 alpha:1]];
    _slider2.text = @"滑动后校验 >";

    _slider2.delegate = self;
//    [self.view addSubview:_slider1];
    [self.view addSubview:_slider2];
//    [self.view addSubview:_slider3];
    //    _slider3.thumbHidden = YES;
    //    [_slider3 removeRoundCorners:YES border:YES];
    
    
}
- (void)sliderEndValueChanged:(HBLockSliderView *)slider{
    if (slider.value == 1) {
        //        slider.thumbBack = NO;
        //        [slider setSliderValue:1.0];
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Success" message:@"解锁成功" delegate:self cancelButtonTitle:@"确定" otherButtonTitles: nil];
        [alert show];
    }
}

- (void)sliderValueChanging:(HBLockSliderView *)slider{
    //    NSLog(@"%f",slider.value);
}

@end
