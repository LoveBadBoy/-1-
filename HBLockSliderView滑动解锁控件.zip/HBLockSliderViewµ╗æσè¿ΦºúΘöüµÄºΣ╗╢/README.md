# HBLockSliderView
快速创建滑动解锁视图，高度自定义

![HBLockSlider.gif](http://upload-images.jianshu.io/upload_images/2100810-4e0d5ac91711e2b9.gif?imageMogr2/auto-orient/strip)

配套简书文章：[iOS 自定义实现滑动解锁功能](http://www.jianshu.com/p/c162afefe713)

