# LaunchIntroductionDemo
a demo for launch guide.
特点：
1、使用简单，一句代码搞定
2、支持自定义指示器的颜色
3、支持应用升级后显示新的引导页

![效果图](https://github.com/hungryBoy/LaunchIntroductionDemo/blob/master/LaunchIntroduction.gif)
