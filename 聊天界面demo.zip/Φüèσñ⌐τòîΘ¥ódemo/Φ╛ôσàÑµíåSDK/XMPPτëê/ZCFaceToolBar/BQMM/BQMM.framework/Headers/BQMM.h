//
//  BQMM.h
//  BQMM SDK
//
//  Created by ceo on 11/10/15.
//  Copyright © 2015 siyanhui. All rights reserved.
//

#ifndef BQMM_h
#define BQMM_h

#define BQMM_VERSION 0x00010202
#define BQMM_BUILD @"release"

#import "MMEmotionCentre.h"
#import "MMTheme.h"
#import "MMEmoji.h"
#import "UITextView+BQMM.H"
#import "MMTextParser.h"
#import "SMTextAttachment.h"


#endif /* BQMM_h */
