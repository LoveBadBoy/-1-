//
//  MessageModel.m
//  WeiChat_1511
//
//  Created by zhangcheng on 16/3/16.
//  Copyright © 2016年 zhangcheng. All rights reserved.
//

#import "MessageModel.h"

@implementation MessageModel
-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{

}
@end
