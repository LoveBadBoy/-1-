# ImageBrowser
仿淘宝商品详情的图片浏览器,双击图片放大缩小，单击退出浏览器<br>

效果如下:<br>

![image](https://github.com/HuangQiang11/ImageBrowser/blob/master/Images/jg090pWVS6.gif)

