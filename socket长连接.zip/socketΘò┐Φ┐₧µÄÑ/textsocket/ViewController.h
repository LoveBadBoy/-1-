//
//  ViewController.h
//  textsocket
//
//  Created by artfox on 2017/6/20.
//  Copyright © 2017年 zhoahongartfox. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

