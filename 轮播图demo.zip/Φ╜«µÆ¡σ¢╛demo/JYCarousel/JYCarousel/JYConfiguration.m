//
//  JYConfiguration.m
//  JYCarousel
//
//  Created by Dely on 16/11/14.
//  Copyright © 2016年 Dely. All rights reserved.
//

#import "JYConfiguration.h"

@implementation JYConfiguration

@end
