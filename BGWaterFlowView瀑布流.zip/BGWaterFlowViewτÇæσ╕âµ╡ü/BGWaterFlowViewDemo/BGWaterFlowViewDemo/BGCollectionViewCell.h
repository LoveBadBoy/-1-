//
//  BGCollectionViewCell.h
//  BGCollectionView
//
//  Created by 杨社兵 on 15/10/25.
//  Copyright © 2015年 FAL. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BGCollectionViewCell : UICollectionViewCell
@property (nonatomic, strong) UIImageView *picImgView;
@property (nonatomic, copy) NSString *urlStr;

@end
