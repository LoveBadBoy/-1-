//
//  ceshicell.m
//  BGWaterFlowViewDemo
//
//  Created by artfox on 2017/5/17.
//  Copyright © 2017年 BG. All rights reserved.
//

#import "ceshicell.h"

@implementation ceshicell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
}

//- (instancetype)initWithFrame:(CGRect)frame {
//    self = [super initWithFrame:frame];
//    if (self) {
//        self = [[NSBundle mainBundle]loadNibNamed:@"ceshicell" owner:self options:nil].lastObject;
//    }
//    return self;
//}
@end
