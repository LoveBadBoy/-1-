//
//  ceshicell.h
//  BGWaterFlowViewDemo
//
//  Created by artfox on 2017/5/17.
//  Copyright © 2017年 BG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ceshicell : UICollectionViewCell

@end
