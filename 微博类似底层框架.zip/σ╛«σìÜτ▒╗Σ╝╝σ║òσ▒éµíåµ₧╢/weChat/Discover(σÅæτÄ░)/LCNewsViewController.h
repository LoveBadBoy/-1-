//
//  LCNewsViewController.h
//  weChat
//
//  Created by Lc on 16/5/6.
//  Copyright © 2016年 LC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LCNewsViewController : UIViewController

@end
