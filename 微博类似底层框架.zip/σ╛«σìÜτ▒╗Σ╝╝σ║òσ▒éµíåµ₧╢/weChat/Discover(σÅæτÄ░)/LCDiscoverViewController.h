//
//  LCDiscoverViewController.h
//  weChat
//
//  Created by 聪 on 16/5/11.
//  Copyright © 2016年 LC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LCDiscoverViewController : UITableViewController

@end
