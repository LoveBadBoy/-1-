//
//  LCBannerCell.h
//  weChat
//
//  Created by Lc on 16/3/29.
//  Copyright © 2016年 LC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LCBannerCell : UITableViewCell
@property (copy, nonatomic) NSString *time;

@property (copy, nonatomic) NSString *alert;
@end
