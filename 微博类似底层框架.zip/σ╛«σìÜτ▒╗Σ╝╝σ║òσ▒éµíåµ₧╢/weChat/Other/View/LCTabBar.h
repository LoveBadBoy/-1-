//
//  LCTabBar.h
//  hotwind
//
//  Created by Lc on 15/7/3.
//  Copyright © 2015年 LC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LCTabBar : UITabBar

@end
