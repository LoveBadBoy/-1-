//
//  LCGroupViewController.h
//  TaiYangHua
//
//  Created by Lc on 16/1/18.
//  Copyright © 2016年 hhly. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LCGroupListViewController : UITableViewController

@end
