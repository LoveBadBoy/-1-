//
//  SubViewController.m
//  JYCarousel
//
//  Created by Dely on 16/11/17.
//  Copyright © 2016年 Dely. All rights reserved.
//

#import "SubViewController.h"
#import "JYCarousel.h"
#import "JYImageCache.h"

@interface SubViewController ()<JYCarouselDelegate>
@property (nonatomic, strong) JYCarousel *carouselView2;

@end

@implementation SubViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self addCarouselView1];
    [self addCarouselView2];
    [self addCarouselView3];
    [self addCarouselView4];
    [self addCarouselView5];

}

- (void)addCarouselView1{
    __weak typeof(self) weakSelf = self;
    //_carouselView1
    NSMutableArray *imageArray = [[NSMutableArray alloc] initWithArray: @[@"1.jpg",@"2.jpg",@"3.jpg",@"4.jpg"]];
    
    JYCarousel *carouselView = [[JYCarousel alloc] initWithFrame:CGRectMake(0, 64, ViewWidth(self.view), 100) configBlock:^JYConfiguration *(JYConfiguration *carouselConfig) {
        carouselConfig.pageContollType = LabelPageControl;
        carouselConfig.interValTime = 3;
        carouselConfig.pushAnimationType = PushCube;
        carouselConfig.animationSubtype = kCATransitionFromRight;
        return carouselConfig;
    } clickBlock:^(NSInteger index) {
        [weakSelf clickIndex:index];
    }];
    //开始轮播
    [carouselView startCarouselWithArray:imageArray];
    [self.view addSubview:carouselView];
}
- (void)addCarouselView2{
    __weak typeof(self) weakSelf = self;
    //_carouselView2
    NSMutableArray *imageArray2 = [[NSMutableArray alloc] initWithArray: @[@"http://static.newnewle.com/bundles/webappindex/upload/user/img/232aa1d6d0d81701599b2770d7507bcd.jpeg",@"http://static.newnewle.com/bundles/webappindex/upload/user/img/ddf806c52b4fffed8d10ea22fe0aefa7.jpeg",@"http://static.newnewle.com/bundles/webappindex/upload/user/img/fbcd050542555e6a4d35cc92f4fc5cec.jpeg",@"http://static.newnewle.com/bundles/webappindex/upload/user/img/d3e7c20acb70b2554825e4fa35919da8.jpeg",@"http://static.newnewle.com/bundles/webappindex/upload/user/img/f58cf571f152660ef09b150f9b3b1f0c.jpeg",@"http://static.newnewle.com/bundles/webappindex/upload/user/img/725621ddcb287ffcb0bc3524e62dfc21.jpeg",@"http://static.newnewle.com/bundles/webappindex/upload/user/img/fe899e8d631d586224edb11fb0842df7.jpeg",@"http://static.newnewle.com/bundles/webappindex/upload/user/img/220ab5198d566031e00e82f9583cd453.jpeg",@"http://static.newnewle.com/bundles/webappindex/upload/user/img/9ef8a9a6ae90a54df25a9727223c3bc2.jpeg"]];
    
    weakSelf.carouselView2 = [[JYCarousel alloc] initWithFrame:CGRectMake(0, 170, ViewWidth(self.view), 100) configBlock:^JYConfiguration *(JYConfiguration *carouselConfig) {
        carouselConfig.pageContollType = MiddlePageControl;
        carouselConfig.pageTintColor = [UIColor whiteColor];
        carouselConfig.currentPageTintColor = [UIColor redColor];
        carouselConfig.placeholder = [UIImage imageNamed:@"default"];
        carouselConfig.faileReloadTimes = 5;
        return carouselConfig;
    } clickBlock:^(NSInteger index) {
        [weakSelf clickIndex:index];
    }];
    
    //开始轮播
    [_carouselView2 startCarouselWithArray:imageArray2];
    [self.view addSubview:_carouselView2];
}


- (void)addCarouselView3{
    __weak typeof(self) weakSelf = self;
    //_carouselView3
    NSMutableArray *imageArray = [[NSMutableArray alloc] initWithArray: @[@"1.jpg",@"2.jpg",@"3.jpg",@"4.jpg"]];
    
    JYCarousel *carouselView = [[JYCarousel alloc] initWithFrame:CGRectMake(0, 300, ViewWidth(self.view), 100) configBlock:^JYConfiguration *(JYConfiguration *carouselConfig) {
        carouselConfig.pageContollType = RightPageControl;
        carouselConfig.interValTime = 2.0;
        carouselConfig.pushAnimationType = PushRippleEffect;
        return carouselConfig;
    } clickBlock:^(NSInteger index) {
        [weakSelf clickIndex:index];
    }];
    
    //开始轮播
    [carouselView startCarouselWithArray:imageArray];
    [self.view addSubview:carouselView];
}


- (void)addCarouselView4{
    __weak typeof(self) weakSelf = self;
    //_carouselView4
    NSMutableArray *imageArray = [[NSMutableArray alloc] initWithArray: @[@"1.jpg",@"2.jpg",@"3.jpg",@"4.jpg"]];
    
    JYCarousel *carouselView = [[JYCarousel alloc] initWithFrame:CGRectMake(0, 420, ViewWidth(self.view), 100) configBlock:^JYConfiguration *(JYConfiguration *carouselConfig) {
        carouselConfig.pageContollType = LeftPageControl;
        carouselConfig.interValTime = 2.5;
        carouselConfig.pushAnimationType = PushCurlUp;
        return carouselConfig;
    } clickBlock:^(NSInteger index) {
        [weakSelf clickIndex:index];
    }];
    
    //开始轮播
    [carouselView startCarouselWithArray:imageArray];
    [self.view addSubview:carouselView];
}

- (void)addCarouselView5{
    //_carouselView5
    NSMutableArray *imageArray = [[NSMutableArray alloc] initWithArray: @[@"1.jpg",@"2.jpg",@"3.jpg",@"4.jpg"]];
    
    JYCarousel *carouselView = [[JYCarousel alloc] initWithFrame:CGRectMake(0, 540, ViewWidth(self.view), 100) configBlock:^JYConfiguration *(JYConfiguration *carouselConfig) {
        carouselConfig.pageContollType = LeftPageControl;
        carouselConfig.interValTime = 3.0;
        carouselConfig.pushAnimationType = PushCameraIrisHollowOpen;
        carouselConfig.backViewImage = [UIImage imageNamed:@"default"];
        return carouselConfig;
    } target:self];
    
    //开始轮播
    [carouselView startCarouselWithArray:imageArray];
    [self.view addSubview:carouselView];
}

- (void)carouselViewClick:(NSInteger)index{
    NSLog(@"代理方式你点击图片索引index = %ld",index);
}

- (void)clickIndex:(NSInteger)index{
    NSLog(@"你点击图片索引index = %ld",index);
    //清除缓存数据 可以在启动的时候清除一次上一次轮播缓存,根据自己需要
    [[JYImageCache sharedImageCache] jy_clearDiskCaches];
}


- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    NSLog(@"进入VC：%@", [[self class] description]);
}
- (void)dealloc{
    NSLog(@"退出VC--无循环引用-----");
}


@end
