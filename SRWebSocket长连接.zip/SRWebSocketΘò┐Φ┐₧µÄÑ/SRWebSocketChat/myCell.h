//
//  myCell.h
//  SRWebSocketChat
//
//  Created by xuran on 16/7/18.
//  Copyright © 2016年 黯丶野火. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface myCell : UITableViewCell
@property (nonatomic, strong) UIImageView * myImageView;
@end
