//
//  SRChatBaseMessage.m
//  SRWebSocketChat
//
//  Created by xuran on 16/6/22.
//  Copyright © 2016年 黯丶野火. All rights reserved.
//

#import "SRChatBaseMessage.h"

@implementation SRChatBaseMessage

@end
