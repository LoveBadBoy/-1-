//
//  XRVerticalInteractiveTransitionAnimation.h
//  SRWebSocketChat
//
//  Created by xuran on 16/7/4.
//  Copyright © 2016年 黯丶野火. All rights reserved.
//

#import "XRBaseInteractiveTransitionAnimation.h"

@interface XRVerticalInteractiveTransitionAnimation : XRBaseInteractiveTransitionAnimation
@property (nonatomic, assign) BOOL popOnRightToLeft;
@end
