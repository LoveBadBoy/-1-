//
//  XRCicleTransitionAnimation.h
//  SRWebSocketChat
//
//  Created by xuran on 16/7/2.
//  Copyright © 2016年 黯丶野火. All rights reserved.
//

#import "XRBaseTransitionAnimation.h"

@interface XRCicleTransitionAnimation : XRBaseTransitionAnimation

@end
