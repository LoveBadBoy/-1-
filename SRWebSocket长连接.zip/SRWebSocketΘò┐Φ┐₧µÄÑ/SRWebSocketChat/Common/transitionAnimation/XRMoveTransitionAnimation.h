//
//  XRMoveTransitionAnimation.h
//  SRWebSocketChat
//
//  Created by xuran on 16/7/25.
//  Copyright © 2016年 黯丶野火. All rights reserved.
//

#import "XRBaseTransitionAnimation.h"

@interface XRMoveTransitionAnimation : XRBaseTransitionAnimation

@end
