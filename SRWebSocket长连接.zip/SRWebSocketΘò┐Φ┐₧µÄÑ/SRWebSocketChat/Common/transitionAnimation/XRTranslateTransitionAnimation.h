//
//  XRTranslateTransitionAnimation.h
//  SRWebSocketChat
//
//  Created by xuran on 16/6/30.
//  Copyright © 2016年 黯丶野火. All rights reserved.
//

#import "XRBaseTransitionAnimation.h"

/**
 custom push / pop animation class.
 */
@interface XRTranslateTransitionAnimation : XRBaseTransitionAnimation

@end
