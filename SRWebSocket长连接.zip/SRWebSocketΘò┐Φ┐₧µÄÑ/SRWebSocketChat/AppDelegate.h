//
//  AppDelegate.h
//  SRWebSocketChat
//
//  Created by xuran on 16/6/22.
//  Copyright © 2016年 黯丶野火. All rights reserved.
//

#import <UIKit/UIKit.h>

@class XRBaseTransitionAnimation;
@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) XRBaseTransitionAnimation * navigationAnimation;
@end

