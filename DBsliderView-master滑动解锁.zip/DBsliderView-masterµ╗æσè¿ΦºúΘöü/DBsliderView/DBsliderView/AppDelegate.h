//
//  AppDelegate.h
//  DBsliderView
//
//  Created by Jdb on 16/1/21.
//  Copyright © 2016年 uimbank. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

