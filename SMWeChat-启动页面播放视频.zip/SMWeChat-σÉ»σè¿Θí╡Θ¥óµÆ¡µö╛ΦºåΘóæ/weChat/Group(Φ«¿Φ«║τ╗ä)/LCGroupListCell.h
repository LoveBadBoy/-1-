//
//  LCGroupListCell.h
//  TaiYangHua
//
//  Created by Lc on 16/1/19.
//  Copyright © 2016年 hhly. All rights reserved.
//

#import <UIKit/UIKit.h>

@class LCGroupList;
@interface LCGroupListCell : UITableViewCell

@property (strong, nonatomic) LCGroupList *internalGroupList;
@end

