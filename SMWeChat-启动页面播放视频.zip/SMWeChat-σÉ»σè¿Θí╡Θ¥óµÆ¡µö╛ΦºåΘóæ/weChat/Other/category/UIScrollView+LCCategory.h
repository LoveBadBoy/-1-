//
//  UIScrollView+LCCategory.h
//  weChat
//
//  Created by Lc on 16/3/30.
//  Copyright © 2016年 LC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIScrollView (LCCategory)

@end
