//
//  LCPlusButton.h
//  weChat
//
//  Created by Lc on 16/5/4.
//  Copyright © 2016年 LC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LCPlusButton : UIButton

@end
