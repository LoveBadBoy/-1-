# startMovie
关于app第一次下载启动的时候的一个视频介绍短片制作  

![image](https://github.com/zhangyqyx/startMovie/blob/master/moviegif/startMovie.gif)
