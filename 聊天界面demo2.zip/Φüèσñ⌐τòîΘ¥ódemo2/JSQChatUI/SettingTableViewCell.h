//
//  SettingTableViewCell.h
//  JSQChatUI
//
//  Created by MKJING on 2016/12/17.
//  Copyright © 2016年 MKJING. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *settingLabel;
@property (weak, nonatomic) IBOutlet UISwitch *rightSwitch;

@end
