//
//  SettingModel.h
//  JSQChatUI
//
//  Created by MKJING on 2016/12/17.
//  Copyright © 2016年 MKJING. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SettingModel : NSObject

@property (nonatomic,copy) NSString *title;
@property (nonatomic,assign) BOOL isOpen;

@end
