//
//  AppDelegate.h
//  JSQChatUI
//
//  Created by MKJING on 2016/12/16.
//  Copyright © 2016年 MKJING. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

