//
//  MKJSocketService.h
//  SocketSeverce
//
//  Created by 宓珂璟 on 2017/2/1.
//  Copyright © 2017年 Deft_Mikejing_iOS_coder. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MKJSocketService : NSObject

- (void)connected;

@end
