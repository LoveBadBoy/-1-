# MKJElegantChatUI  聊天UI框架
<img src="https://github.com/DeftMKJ/MKJElegantChatUI/blob/master/1.png" alt="UI" title="Deftmikejing" width="375" height="667" />&nbsp;&nbsp;&nbsp;
<img src="https://github.com/DeftMKJ/MKJElegantChatUI/blob/master/2.png" alt="UI" title="Deftmikejing" width="375" height="667" />
