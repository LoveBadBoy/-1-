//
//  CorePagesBarBtn.h
//  CorePagesView
//
//  Created by muxi on 15/3/20.
//  Copyright (c) 2015年 muxi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CorePagesBarBtn : UIButton

@end
