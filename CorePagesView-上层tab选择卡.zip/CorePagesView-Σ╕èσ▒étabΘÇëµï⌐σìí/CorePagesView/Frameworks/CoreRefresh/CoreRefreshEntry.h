//
//  CoreRefreshEntry.h
//  CoreRefresh
//
//  Created by 沐汐 on 15-1-18.
//  Copyright (c) 2015年 沐汐. All rights reserved.
//  核心刷新库全局头文件
//
//  本框架基本MJRefresh
//  本框架请使用setState来表达各种状态
//  建议在viewDidAppear中添加刷新控件
//  在viewDidDisappear中移除

#import "UIScrollView+Refresh.h"