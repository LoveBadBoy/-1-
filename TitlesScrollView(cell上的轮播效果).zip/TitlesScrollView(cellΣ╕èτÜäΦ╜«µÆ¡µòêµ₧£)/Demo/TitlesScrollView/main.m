//
//  main.m
//  TitlesScrollView
//
//  Created by Peter Kong on 15/7/5.
//  Copyright (c) 2015年 CrazyPeter. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
