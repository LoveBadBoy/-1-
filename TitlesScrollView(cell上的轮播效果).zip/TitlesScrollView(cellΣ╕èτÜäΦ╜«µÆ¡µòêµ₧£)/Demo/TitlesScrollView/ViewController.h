//
//  ViewController.h
//  TitlesScrollView
//
//  Created by Peter Kong on 15/7/5.
//  Copyright (c) 2015年 CrazyPeter. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

