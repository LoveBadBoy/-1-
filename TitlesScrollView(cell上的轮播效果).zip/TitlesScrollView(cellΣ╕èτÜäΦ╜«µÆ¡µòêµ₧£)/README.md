# TitlesScrollView

###What's this
    ControlView For "titles in Slider"
![](http://g.recordit.co/nJbSjBmuKS.gif)  

###How to use
    just clone this project,see the src folder,read .h file
    
###Attention
    1.no cocoapods surpport,it's too easy,no need cocoapods
    2.no "swift vertion" on plan,if you need that,you can rewrite this view by your self.
    
####if you like it ,you can buy me a cup of coffee,Alipay:k9629@163.com
    
<br> <br> <br> 
    
###这是什么
    一个展示文字标题相关的动效，一图流
![](http://g.recordit.co/nJbSjBmuKS.gif)  

###如何使用
    clone这个项目到本地，看src文件夹里面的.h文件，里面有详细的注释
    
###其他注意事项
    1.不提供 cocoapods 的支持,因为项目太简单了,只依靠UIKit,不需要cocoapods这种“牛刀”
    2.作者不提供swift版本，项目很简单，如果你需要的话，可以自己重写一个swift版本。
    
    
####如果你喜欢这个项目，你可以资助我继续发扬开源精神，支付宝帐号:k9629@163.com
