# STTTextHud
#####目录
![image](https://github.com/strivever/STTTextHud/blob/master/STHudTextDemo/截图/2.png)
#####未设置延迟提示
![image](https://github.com/strivever/STTTextHud/blob/master/STHudTextDemo/截图/6.png)
#####自己设置延迟提示
![image](https://github.com/strivever/STTTextHud/blob/master/STHudTextDemo/截图/7.png)
#####自己失败提示
![image](https://github.com/strivever/STTTextHud/blob/master/STHudTextDemo/截图/4.png)
#####成功提示
![image](https://github.com/strivever/STTTextHud/blob/master/STHudTextDemo/截图/5.png)
#####数据请求等待
![image](https://github.com/strivever/STTTextHud/blob/master/STHudTextDemo/截图/3.png)
#####带标题数据请求等待
![image](https://github.com/strivever/STTTextHud/blob/master/STHudTextDemo/截图/1.png)
#####菊花等待框
![image](https://github.com/strivever/STTTextHud/blob/master/STHudTextDemo/截图/0.png)
