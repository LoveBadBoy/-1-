//
//  GCLoadingView.h
//  LiquoriceDoctorProject
//
//  Created by HenryCheng on 15/12/4.
//  Copyright © 2015年 iMac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GCLoadingView : UIView

- (void)startAnimating;
- (void)stopAnimating;

@end
