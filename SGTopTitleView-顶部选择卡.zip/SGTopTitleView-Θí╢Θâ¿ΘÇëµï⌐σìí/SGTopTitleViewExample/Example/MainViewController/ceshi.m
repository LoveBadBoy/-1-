//
//  ceshi.m
//  SGTopTitleViewExample
//
//  Created by artfox on 2017/5/15.
//  Copyright © 2017年 JP_lee. All rights reserved.
//

#import "ceshi.h"

// Controllers

// Model

// Views


//#define <#macro#> <#value#>


@interface ceshi ()


@end

@implementation ceshi


#pragma mark - View Controller LifeCyle

- (instancetype)initWithCoder:(NSCoder *)coder
{
    self = [super initWithCoder:coder];
    if (self) {
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self initialNavigationBar];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}




#pragma mark - Override

#pragma mark - Initial Methods

- (void)initialNavigationBar
{
    //    self.navigationItem.title = <#title#>;
}


#pragma mark - Target Methods


#pragma mark - Notification Methods


#pragma mark - KVO Methods


#pragma mark - UITableViewDelegate, UITableViewDataSource


#pragma mark - Privater Methods


#pragma mark - Setter Getter Methods

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
#pragma mark - 收到内存警告
- (void)didReceiveMemoryWarning {
    
    [super didReceiveMemoryWarning];
}

@end
