//
//  SGNavigationItemTitleView.m
//  SGTopTitleViewExample
//
//  Created by Sorgle on 16/8/25.
//  Copyright © 2016年 Sorgle. All rights reserved.
//

#import "SGNavigationItemTitleView.h"

@implementation SGNavigationItemTitleView

- (void)setFrame:(CGRect)frame {
    [super setFrame:CGRectMake(0, 0, self.superview.bounds.size.width, self.superview.bounds.size.height)];
}

@end
